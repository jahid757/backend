import React from "react"
import PropTypes from "prop-types"
import { Route, Redirect } from "react-router-dom"

const Authmiddleware = ({
  component: Component,
  layout: Layout,
  isAuthProtected,
  isAdmin,
  ...rest
}) => (
  <Route
    {...rest}
    render={props => {

      // TODO: Simply check if user is an admin through a bool on the user.
      if (isAuthProtected && !localStorage.getItem("authUser")) {
        return (
          <Redirect
            to={{ pathname: "/login", state: { from: props.location } }}
          />
        )
      }

      const authUser = JSON.parse(localStorage.getItem("authUser"));

      if (isAdmin && !authUser.isAdmin)  {
        return (
          <Redirect
            to={{ pathname: "/client-dashboard", state: { from: props.location } }}
          />
        )
      }

      return (
        <Layout>
          <Component {...props} />
        </Layout>
      )
    }}
  />
)

Authmiddleware.propTypes = {
  isAuthProtected: PropTypes.bool,
  component: PropTypes.any,
  location: PropTypes.object,
  layout: PropTypes.any,
}

export default Authmiddleware
